const DataTable=(props)=>{
    const {val, data}= props
    let ind= data.findIndex(item=>{
        return item.Country===val
    })
    return(
        <div className="maintable">
            <p>{data.Date}</p>
            <table>
                <tbody>
                    <tr>
                        <td>Total Confirmed</td>
                        <td>{data[ind].TotalConfirmed}</td>
                        <td>Total Confirmed</td>
                        <td>{data[ind].TotalConfirmed}</td>
                        
                    </tr>
                </tbody>
            </table>
        </div>
    )
}
export default DataTable;
