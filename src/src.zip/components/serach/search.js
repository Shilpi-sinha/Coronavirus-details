import { useState } from 'react'
import DataTable from '../dataTable/dataTable'
import "./style.css"
const Search=(props)=>{
    const {data}= props
    const [val,setVal]= useState(0)   
    const carr=data.Countries
    var handleClick=(e)=>{
        setVal(e.target.value)
        console.log(val)
        return(
            <DataTable val={val} data={carr}/>
        )
    }
    console.log(carr)
    var c=carr.map(item=>{
        return (
            <option onChange={handleClick}>{item.Country}</option>
        )
    })   
    return(
        <div id="main">     
        <select id="dropdown" className="dropdown">
          {c}       
        </select>       
        </div>
    )
}
export default Search